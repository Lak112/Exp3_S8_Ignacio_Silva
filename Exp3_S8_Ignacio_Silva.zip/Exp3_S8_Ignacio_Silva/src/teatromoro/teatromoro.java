/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package teatromoro;

/**
 *
 * @author ignac
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class teatromoro {
    private static int totalIngresos = 0;
    private static int totalEntradasVendidas = 0;
    private static List<Venta> ventas = new ArrayList<>();
    private static List<String> promociones = new ArrayList<>();

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Bienvenido al Teatro Moro");

        promociones.add("Descuento del 10% para estudiantes.");
        promociones.add("Descuento del 15% para adultos mayores.");

        int opcion;
        do {
            System.out.println("\nMenu:");
            System.out.println("1. Comprar entradas");
            System.out.println("2. Imprimir boleta");
            System.out.println("3. Mostrar resumen de ventas");
            System.out.println("4. Promociones");
            System.out.println("5. Ver entradas vendidas");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opcion: ");
            opcion = input.nextInt();
            input.nextLine(); // Limpiar el buffer del scanner

            switch (opcion) {
                case 1:
                    comprarEntradas(input);
                    break;
                case 2:
                    imprimirBoleta();
                    break;
                case 3:
                    mostrarResumenVentas();
                    break;
                case 4:
                    mostrarPromociones();
                    break;
                case 5:
                    verEntradasVendidas();
                    break;
                case 6:
                    System.out.println("Gracias por utilizar nuestro servicio.");
                    break;
                default:
                    System.out.println("Opcion no valida. Seleccione una opcion valida.");
                    break;
            }
        } while (opcion != 6);

        input.close();
    }

    public static void comprarEntradas(Scanner input) {
        System.out.println("Compra de Entradas:");
        System.out.println("Por favor, seleccione la ubicacion del asiento (VIP, Platea Baja, Platea Alta, Palcos):");
        String ubicacion = input.nextLine().toLowerCase();

        int precioBase = condicionEntrada(ubicacion);
        if (precioBase == 0) {
            System.out.println("Ubicacion no valida.");
            return;
        }

        System.out.println("Tipo de persona (estudiante, adulto mayor, publico general):");
        String tipoPersona = input.nextLine().toLowerCase();
        
        Venta venta = new Venta();
        venta.setIdVenta(totalEntradasVendidas + 1);
        venta.setUbicacion(ubicacion);
        venta.setCostoBase(precioBase);
        venta.setDescuento(calcularDescuento(tipoPersona));
        venta.setCostoFinal(precioBase * (1 - calcularDescuento(tipoPersona) / 100));
        ventas.add(venta);

        // Actualizar estadísticas globales
        totalIngresos += venta.getCostoFinal();
        totalEntradasVendidas++;

        System.out.println("Compra realizada exitosamente:");
        System.out.println("ID de Venta: " + venta.getIdVenta());
        System.out.println("Ubicacion del asiento: " + ubicacion);
        System.out.println("Tipo de persona: " + tipoPersona);
        System.out.println("Costo base: $" + precioBase);
        System.out.println("Descuento aplicado: " + venta.getDescuento() + "%");
        System.out.println("Costo final: $" + venta.getCostoFinal());
    }

    public static void imprimirBoleta() {
        System.out.println("\nBoleta:");
        for (Venta venta : ventas) {
            System.out.println("----------------------------------------");
            System.out.println("Teatro Moro");
            System.out.println("Ubicacion del asiento: " + venta.getUbicacion());
            System.out.println("Costo base: $" + venta.getCostoBase());
            System.out.println("Descuento aplicado: " + venta.getDescuento() + "%");
            System.out.println("Costo final: $" + venta.getCostoFinal());
            System.out.println("Gracias por su visita al Teatro Moro.");
        }
    }

    public static void mostrarResumenVentas() {
        System.out.println("\nResumen de Ventas:");
        for (Venta venta : ventas) {
            System.out.println("----------------------------------------");
            System.out.println("ID de Venta: " + venta.getIdVenta());
            System.out.println("Ubicacion del asiento: " + venta.getUbicacion());
            System.out.println("Costo final: $" + venta.getCostoFinal());
        }
    }

    public static void mostrarPromociones() {
        System.out.println("\nPromociones disponibles:");
        for (String promocion : promociones) {
            System.out.println("- " + promocion);
        }
    }

    public static void verEntradasVendidas() {
        System.out.println("\nEntradas vendidas: " + totalEntradasVendidas);
        System.out.println("Total de ingresos: $" + totalIngresos);
    }

    public static int condicionEntrada(String ubicacion) {
        switch (ubicacion) {
            case "vip":
                return 25000;
            case "platea baja":
                return 19000;
            case "platea alta":
                return 11000;
            case "palcos":
                return 7200;
            default:
                return 0;
        }
    }

    public static int calcularDescuento(String tipoPersona) {
        switch (tipoPersona) {
            case "estudiante":
                return 10; // Descuento del 10% para estudiantes
            case "adulto mayor":
                return 15; // Descuento del 15% para adultos mayores
            default:
                return 0;
        }
    }
}
