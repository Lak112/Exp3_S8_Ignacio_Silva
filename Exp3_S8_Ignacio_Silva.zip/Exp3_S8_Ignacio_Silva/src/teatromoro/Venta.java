/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package teatromoro;

/**
 *
 * @author ignac
 */
public class Venta {

    public Venta() {
    }
    private int idVenta;
    private String ubicacion;
    private int costoBase;
    private int descuento;
    private int costoFinal;

    public Venta(int idVenta, String ubicacion, int costoBase, int descuento, int costoFinal) {        
        this.idVenta = idVenta;
        this.ubicacion = ubicacion;
        this.costoBase = costoBase;
        this.descuento = descuento;
        this.costoFinal = costoFinal;
    }
    
    public void setIdVenta(int idVenta) {
        this.idVenta = idVenta;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public void setCostoBase(int costoBase) {
        this.costoBase = costoBase;
    }

    public void setDescuento(int descuento) {
        this.descuento = descuento;
    }

    public void setCostoFinal(int costoFinal) {
        this.costoFinal = costoFinal;
    }
    public int getIdVenta() {
        return idVenta;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public int getCostoBase() {
        return costoBase;
    }

    public int getDescuento() {
        return descuento;
    }

    public int getCostoFinal() {
        return costoFinal;
    }
}
